<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// --- ROTAS PÚBLICAS ---
$routes->get('/', 'Home::index');

// --- AUTENTICAÇÃO ---
$routes->get('/login', 'AuthController::login');
$routes->post('/autenticar', 'AuthController::autenticar');
$routes->get('/registro', 'AuthController::registro');
$routes->post('/cadastrar', 'AuthController::cadastrar');
$routes->get('/logout', 'AuthController::logout');

// --- ÁREA PROTEGIDA (LOGADOS) ---
$routes->group('', ['filter' => 'auth'], function ($routes) {

    $routes->get('dashboard', 'DashboardController::index');

    // Perfil do Usuário (Onde ele altera os próprios dados)
    $routes->get('perfil', 'PerfilController::index');
    $routes->post('perfil/salvar', 'PerfilController::salvar');

    // Reservas do Usuário Comum
    $routes->group('reservas', function ($routes) {
        $routes->get('/', 'ReservaController::index');
        $routes->get('nova', 'ReservaController::criar');
        $routes->post('agendar', 'ReservaController::agendar');
        $routes->get('cancelar/(:num)', 'ReservaController::cancelar/$1');
        $routes->get('editar/(:num)', 'ReservaController::editar/$1');
        $routes->post('atualizar/(:num)', 'ReservaController::atualizar/$1');

        $routes->get('calendario', 'ReservaController::calendario');
        $routes->get('eventos-json', 'ReservaController::eventosJson');
    });

    // --- ÁREA RESTRITA (APENAS NÍVEL 0 - ADMIN) ---
    $routes->group('admin', ['filter' => 'adminFilter'], function ($routes) {

        // Gestão Global de Reservas (Ver tudo)
        $routes->get('reservas', 'AdminController::todasReservas');

        // Gerenciamento de Salas
        $routes->get('salas', 'SalaController::index');
        $routes->get('salas/nova', 'SalaController::criar');
        $routes->post('salas/salvar', 'SalaController::salvar');

        // Gerenciamento de Usuários
        $routes->get('usuarios', 'AdminController::usuarios');
        $routes->get('usuarios/mudar-nivel/(:num)/(:num)', 'AdminController::mudarNivel/$1/$2');
        $routes->post('alterar-senha/(:num)', 'AdminController::alterarSenhaUsuario/$1');
    });
});

$routes->post('chatbot/processar', 'ChatbotController::processar');
