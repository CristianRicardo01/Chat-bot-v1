<?= $this->extend('layouts/main') ?> <?= $this->section('content') ?>
<div class="row justify-content-center mt-5">
    <div class="col-md-4">
        <div class="card shadow border-0">
            <div class="card-body p-4">
                <h3 class="text-center mb-4">Criar Conta</h3>
                
                <form action="<?= base_url('cadastrar') ?>" method="POST">
                    <?= csrf_field() ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Nome Completo</label>
                        <input type="text" name="nome" class="form-control" placeholder="Seu nome" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">E-mail</label>
                        <input type="email" name="email" class="form-control" placeholder="nome@empresa.com" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Senha</label>
                        <input type="password" name="senha" class="form-control" placeholder="No mínimo 6 caracteres" required>
                    </div>

                    <button type="submit" class="btn btn-primary w-100">Registrar</button>
                </form>
                
                <div class="text-center mt-3">
                    <small>Já tem conta? <a href="<?= base_url('login') ?>">Faça Login</a></small>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>