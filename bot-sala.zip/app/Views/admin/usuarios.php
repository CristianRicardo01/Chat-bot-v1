<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Gerenciar Usuários 👥</h2>
</div>

<div class="card shadow border-0">
    <div class="card-body">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Nível Atual</th>
                    <th>Ações / Reset de Senha</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($usuarios as $user): ?>
                    <tr>
                        <td><?= $user['nome'] ?></td>
                        <td><?= $user['email'] ?></td>
                        <td>
                            <?php if ($user['nivel'] == 0): ?>
                                <span class="badge bg-danger">Administrador</span>
                            <?php else: ?>
                                <span class="badge bg-primary">Usuário Comum</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php if ($user['id'] != session()->get('id')): ?>
                                    <?php if ($user['nivel'] == 1): ?>
                                        <a href="<?= base_url('admin/usuarios/mudar-nivel/' . $user['id'] . '/0') ?>" class="btn btn-sm btn-outline-danger">Promover</a>
                                    <?php else: ?>
                                        <a href="<?= base_url('admin/usuarios/mudar-nivel/' . $user['id'] . '/1') ?>" class="btn btn-sm btn-outline-secondary">Rebaixar</a>
                                    <?php endif; ?>

                                    <button type="button" class="btn btn-sm btn-warning"
                                        data-bs-toggle="modal"
                                        data-bs-target="#modalSenha"
                                        data-id="<?= $user['id'] ?>"
                                        data-nome="<?= $user['nome'] ?>">
                                        Nova Senha
                                    </button>
                                <?php else: ?>
                                    <small class="text-muted">Você (Atual)</small>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="d-flex justify-content-center mt-3">
            <?= $pager->links('usuarios', 'bootstrap5') ?>
        </div>
    </div>
</div>

<!-- Modal para Alterar Senha -->
<div class="modal fade" id="modalSenha" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="formResetSenha" method="POST" action="">
                <div class="modal-header">
                    <h5 class="modal-title">Redefinir Senha</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Alterando senha de: <strong id="nomeUsuarioModal"></strong></p>
                    <div class="mb-3">
                        <label class="form-label">Nova Senha</label>
                        <input type="password" name="nova_senha" class="form-control" required minlength="6">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-warning">Salvar Nova Senha</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modalSenha = document.getElementById('modalSenha');
    modalSenha.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget;
        const id = button.getAttribute('data-id');
        const nome = button.getAttribute('data-nome');

        const form = modalSenha.querySelector('#formResetSenha');
        const nomeDisplay = modalSenha.querySelector('#nomeUsuarioModal');

        // Atualiza o link do formulário com o ID correto e o nome no texto
        form.action = '<?= base_url('admin/alterar-senha/') ?>' + id;
        nomeDisplay.textContent = nome;
    });
</script>
<?= $this->endSection() ?>