<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h2 class="mb-0">Gestão Global de Reservas 🌍</h2>
        <small class="text-muted">Visualização de todos os agendamentos do sistema</small>
    </div>
</div>

<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= base_url('admin/reservas') ?>" method="GET" class="row g-3">
            <div class="col-md-3">
                <label class="form-label small fw-bold">Filtrar por data:</label>
                <input type="date" name="data" class="form-control" value="<?= $data_selecionada ?>">
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-secondary me-2">Filtrar</button>
                <a href="<?= base_url('admin/reservas') ?>" class="btn btn-link btn-sm text-decoration-none">Limpar Filtro</a>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm border-0">
    <div class="card-body">
        <table class="table table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>Data</th>
                    <th>Sala</th>
                    <th>Quem Reservou</th>
                    <th>Horário</th>
                    <th class="text-center">Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reservas)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4">Nenhuma reserva encontrada para os filtros aplicados.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($reservas as $reserva):
                        $agora = new DateTime();
                        $fimReserva = new DateTime($reserva['data_reserva'] . ' ' . $reserva['hora_fim']);
                        $finalizada = ($agora > $fimReserva);
                    ?>
                        <tr>
                            <td><?= date('d/m/Y', strtotime($reserva['data_reserva'])) ?></td>
                            <td><span class="badge bg-info text-dark"><?= $reserva['nome_sala'] ?></span></td>
                            <td>
                                <strong><?= $reserva['nome_usuario'] ?></strong><br>
                                <small class="text-muted"></small>
                            </td>
                            <td><?= $reserva['hora_inicio'] ?> às <?= $reserva['hora_fim'] ?></td>
                            <td class="text-center">
                                <?php if ($finalizada): ?>
                                    <span class="badge bg-success px-3">Finalizado</span>
                                <?php else: ?>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <a href="<?= base_url('reservas/editar/' . $reserva['id']) ?>"
                                            class="btn btn-sm btn-outline-warning border-2"
                                            title="Editar Reserva">
                                            ✏️
                                        </a>

                                        <a href="<?= base_url('reservas/cancelar/' . $reserva['id']) ?>"
                                            class="btn btn-sm btn-outline-danger border-2"
                                            onclick="return confirm('Tem certeza que deseja cancelar esta reserva?')"
                                            title="Cancelar Reserva">
                                            🗑️
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center mt-3">
            <?= $pager->links('reservas', 'bootstrap5') ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>