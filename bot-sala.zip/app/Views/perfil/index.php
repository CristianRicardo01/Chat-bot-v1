<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow border-0">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">Meu Perfil 👤</h4>
            </div>
            <div class="card-body p-4">
                
                <form action="<?= base_url('perfil/salvar') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label class="form-label fw-bold">E-mail (Não pode ser alterado)</label>
                        <input type="email" class="form-control bg-light" value="<?= $usuario['email'] ?>" readonly>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Nome Completo</label>
                        <input type="text" name="nome" class="form-control" value="<?= $usuario['nome'] ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Nova Senha</label>
                        <input type="password" name="senha" class="form-control" placeholder="Deixe em branco para manter a atual">
                        <div class="form-text">Mínimo de 6 caracteres se desejar alterar.</div>
                    </div>

                    <hr>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>