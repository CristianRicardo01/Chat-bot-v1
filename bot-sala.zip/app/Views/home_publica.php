<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hero { background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1200'); height: 80vh; background-size: cover; color: white; }
    </style>
</head>
<body>
    <nav class="navbar navbar-light bg-light shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="#">🤖 BotReserva</a>
            <div>
                <a href="/login" class="btn btn-outline-primary me-2">Login</a>
                <a href="/registro" class="btn btn-primary">Registrar-se</a>
            </div>
        </div>
    </nav>

    <div class="hero d-flex align-items-center text-center">
        <div class="container">
            <h1 class="display-3 fw-bold">Gestão Inteligente de Salas</h1>
            <p class="lead">Reserve seu espaço em segundos com nosso assistente digital.</p>
        </div>
    </div>
</body>
</html>