<?php $pager->setSurroundCount(0) ?>

<nav aria-label="Navegação de página">
    <ul class="pagination pagination-sm mb-0">
        <?php if ($pager->hasPrevious()) : ?>
            <li class="page-item">
                <a class="page-link" href="<?= $pager->getPrevious() ?>" aria-label="Anterior">
                    <span>&laquo;</span>
                </a>
            </li>
        <?php endif ?>

        <li class="page-item disabled">
            <span class="page-link text-dark">
                <?= $pager->getCurrentPageNumber() ?> / <?= $pager->getPageCount() ?>
            </span>
        </li>

        <?php if ($pager->hasNext()) : ?>
            <li class="page-item">
                <a class="page-link" href="<?= $pager->getNext() ?>" aria-label="Próxima">
                    <span>&raquo;</span>
                </a>
            </li>
        <?php endif ?>
    </ul>
</nav>