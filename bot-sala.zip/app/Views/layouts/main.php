<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bot de Salas - CI4</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <style>
        body {
            background-color: #f8f9fa;
        }

        .navbar {
            margin-bottom: 30px;
        }

        /* Estilo do Chatbot */
        #chatbot-container {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 350px;
            z-index: 9999;
            background: white;
            transition: all 0.3s ease;
        }

        /* Botão Flutuante Estilo Telegram */
        .chat-toggle-btn {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            z-index: 10000;
            background-color: #0088cc;
            /* Cor oficial Telegram */
            color: white;
            border: none;
            cursor: pointer;
            transition: transform 0.2s;
        }

        .chat-toggle-btn:hover {
            transform: scale(1.1);
            color: white;
        }

        /* Badge de Notificação Informando o Chat */
        .chat-badge {
            position: absolute;
            top: -5px;
            left: -10px;
            background-color: #ff3b30;
            color: white;
            font-size: 10px;
            padding: 4px 8px;
            border-radius: 10px;
            font-weight: bold;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }

        .chat-bubble {
            max-width: 85%;
            width: fit-content;
            word-wrap: break-word;
            padding: 10px 15px;
            border-radius: 18px;
            font-size: 0.9rem;
        }

        .chat-bubble.user {
            background-color: #0088cc !important;
            color: white;
            margin-left: auto;
            border-bottom-right-radius: 2px;
        }

        .chat-bubble.bot {
            background-color: #f1f0f0;
            color: #333;
            margin-right: auto;
            border-bottom-left-radius: 2px;
        }

        /* Avião de papel no botão de envio */
        .btn-send-telegram {
            background: none;
            border: none;
            color: #0088cc;
            font-size: 1.5rem;
            padding: 0;
            transition: color 0.2s;
        }

        .btn-send-telegram:hover {
            color: #006699;
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url('dashboard') ?>">🤖 Bot Reserva</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('dashboard') ?>">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('reservas/calendario') ?>">📅 Mapa</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?= base_url('reservas') ?>">Minhas Reservas</a></li>
                    <?php if (session()->get('nivel') == 0): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-warning" href="#" data-bs-toggle="dropdown">🛡️ Admin</a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?= base_url('admin/reservas') ?>">Gestão Global</a></li>
                                <li><a class="dropdown-item" href="<?= base_url('admin/salas') ?>">Salas</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item d-flex align-items-center">
                        <span class="navbar-text me-3 text-white small">Olá, <strong><?= session()->get('nome') ?></strong></span>
                    </li>
                    <li class="nav-item"><a class="btn btn-outline-danger btn-sm" href="<?= base_url('logout') ?>">Sair</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container pb-5">
        <?= $this->renderSection('content') ?>
    </div>

    <div id="chatbot-container" class="shadow-lg border-0 rounded-4 overflow-hidden d-none">
        <div class="card border-0">
            <div class="card-header bg-dark text-white d-flex justify-content-between align-items-center py-3">
                <h6 class="mb-0"><i class="bi bi-robot me-2"></i> Assistente Virtual</h6>
                <button type="button" class="btn-close btn-close-white" onclick="toggleChat()"></button>
            </div>
            <div id="chat-messages" class="card-body overflow-auto" style="height: 380px; background-color: #e5ddd5;">
                <div class="chat-bubble bot mb-3 shadow-sm">
                    Olá! Sou seu assistente. Como posso ajudar com as salas hoje?
                </div>
                <div class="chat-bubble bot mb-3 shadow-sm">
                    Precisa de ajuda? Digite !Informações para ver o que eu posso fazer.<br>
                </div>
            </div>
            <div class="card-footer bg-white p-3">
                <div class="d-flex align-items-center">
                    <input type="text" id="chat-input" class="form-control border-0 bg-light" placeholder="Escreva uma mensagem..." onkeypress="handleKeyPress(event)">
                    <button class="btn-send-telegram ms-2" onclick="sendMessage()">
                        <i class="bi bi-send-fill"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <button onclick="toggleChat()" class="chat-toggle-btn rounded-circle shadow-lg">
        <span class="chat-badge">CHAT</span>
        <i class="bi bi-telegram" style="font-size: 2rem; margin-right: 2px;"></i>
    </button>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function toggleChat() {
            const container = document.getElementById('chatbot-container');
            container.classList.toggle('d-none');
            // Remove o badge se ele existir
            const badge = document.querySelector('.chat-badge');
            if (badge) badge.style.display = 'none';
        }

        function handleKeyPress(e) {
            if (e.key === 'Enter') sendMessage();
        }

        async function sendMessage() {
            const input = document.getElementById('chat-input');
            const text = input.value.trim();

            if (!text) return;

            appendMessage('user', text);
            input.value = '';

            const messages = document.getElementById('chat-messages');
            const typingId = 'typing-' + Date.now();
            const typingDiv = document.createElement('div');
            typingDiv.id = typingId;
            typingDiv.className = 'chat-bubble bot mb-3 small italic text-muted';
            typingDiv.innerHTML = '<i class="bi bi-three-dots"></i> Analisando solicitação...';
            messages.appendChild(typingDiv);
            messages.scrollTop = messages.scrollHeight;

            try {
                const formData = new FormData();
                formData.append('mensagem', text);

                const response = await fetch('<?= base_url("chatbot/processar") ?>', {
                    method: 'POST',
                    body: formData
                });

                if (!response.ok) throw new Error('Erro na rede');

                const data = await response.json();

                setTimeout(() => {
                    const typingElement = document.getElementById(typingId);
                    if (typingElement) typingElement.remove();
                    appendMessage('bot', data.resposta);

                    // --- NOVIDADE AQUI: Gatilho de Atualização ---
                    if (data.status === 'success') {
                        // Criamos um evento para avisar a página que algo mudou
                        window.dispatchEvent(new CustomEvent('reservaConcluida'));
                    }
                }, 600);

            } catch (e) {
                setTimeout(() => {
                    const typingElement = document.getElementById(typingId);
                    if (typingElement) typingElement.remove();
                    appendMessage('bot', "Estou com problemas para conectar ao servidor agora. 🔌");
                }, 600);
            }
        }

        // --- NOVIDADE AQUI: Ouvinte para atualizar a UI sem F5 ---
        window.addEventListener('reservaConcluida', function() {
            console.log("Atualizando componentes da tela...");

            // 1. Se existir uma tabela de reservas, recarrega apenas o conteúdo dela
            const tabela = document.querySelector('#tabela-reservas'); // Ajuste o ID conforme sua view
            if (tabela) {
                // Recarrega a div da tabela usando o próprio URL da página
                fetch(window.location.href)
                    .then(response => response.text())
                    .then(html => {
                        const parser = new DOMParser();
                        const doc = parser.parseFromString(html, 'text/html');
                        const novaTabela = doc.querySelector('#tabela-reservas');
                        if (novaTabela) tabela.innerHTML = novaTabela.innerHTML;
                    });
            }

            // 2. Se estiver usando FullCalendar, ele atualiza os eventos na hora
            if (typeof calendar !== 'undefined') {
                calendar.refetchEvents();
            }
        });

        function appendMessage(sender, text) {
            const messages = document.getElementById('chat-messages');
            const div = document.createElement('div');
            // Usamos innerHTML para permitir que o PHP envie quebras de linha (<br>) se necessário
            div.className = `chat-bubble ${sender} mb-3 shadow-sm`;
            div.style.whiteSpace = "pre-wrap"; // Mantém as quebras de linha do texto
            div.innerText = text;
            messages.appendChild(div);
            messages.scrollTop = messages.scrollHeight;
        }
    </script>
</body>

</html>