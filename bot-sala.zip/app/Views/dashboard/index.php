<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css' rel='stylesheet' />
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/pt-br.js'></script>

<h2 class="mb-4">Olá, <?= session()->get('nome') ?>! 👋</h2>

<div class="row">
    <div class="col-md-4">
        <div class="card bg-primary text-white shadow-sm mb-4">
            <div class="card-body text-center">
                <h6>Minhas Reservas Totais</h6>
                <h2 class="display-4"><?= $minhasReservas ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-success text-white shadow-sm mb-4">
            <div class="card-body text-center">
                <h6>Reservas Hoje (Geral)</h6>
                <h2 class="display-4"><?= $reservasHoje ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-dark text-white shadow-sm mb-4">
            <div class="card-body text-center">
                <h6>Salas Cadastradas</h6>
                <h2 class="display-4"><?= $totalSalas ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="row mt-2">
    <div class="col-md-8">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0">📅 Meus Agendamentos</h4>

            <form action="<?= base_url('dashboard') ?>" method="GET" class="d-flex gap-2">
                <input type="date" name="data_busca" class="form-control form-control-sm" value="<?= $data_selecionada ?? '' ?>">
                <button type="submit" class="btn btn-sm btn-primary">Filtrar</button>
                <?php if (!empty($data_selecionada)): ?>
                    <a href="<?= base_url('dashboard') ?>" class="btn btn-sm btn-outline-secondary">Limpar</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <table class="table table-hover mb-0 align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Data</th>
                            <th>Horário</th>
                            <th>Sala</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($proximasReservas)): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-muted">Nenhuma reserva encontrada.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($proximasReservas as $res): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($res['data_reserva'])) ?></td>
                                    <td><?= $res['hora_inicio'] ?> - <?= $res['hora_fim'] ?></td>
                                    <td><strong><?= $res['nome_sala'] ?? 'N/A' ?></strong></td>
                                    <td><span class="badge bg-info text-dark shadow-sm">Agendado</span></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer bg-white border-0 py-3">
                <div class="d-flex justify-content-center">
                    <?= $pager->links('dashboard', 'bootstrap5_small') ?>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <h4>Calendário de Ocupação</h4>
        <div class="card shadow-sm border-0">
            <div class="card-body p-2">
                <div id="mini-calendar"></div>
            </div>
        </div>
        <div class="d-grid mt-3">
            <a href="<?= base_url('reservas/calendario') ?>" class="btn btn-secondary btn-sm shadow-sm">Ver em Tela Cheia</a>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var miniCalEl = document.getElementById('mini-calendar');
        var miniCalendar = new FullCalendar.Calendar(miniCalEl, {
            initialView: 'dayGridMonth',
            locale: 'pt-br',
            headerToolbar: {
                left: 'prev',
                center: 'title',
                right: 'next'
            },
            height: 'auto',
            aspectRatio: 1.2,
            events: '<?= base_url('reservas/eventos-json') ?>'
        });
        miniCalendar.render();
    });
</script>

<style>
    #mini-calendar {
        font-size: 0.75em;
    }

    .fc-toolbar-title {
        font-size: 1.1em !important;
        text-transform: capitalize;
    }

    .fc-daygrid-day-number {
        text-decoration: none;
        color: #666;
    }

    .fc-event-title {
        font-weight: bold;
    }
</style>

<?= $this->endSection() ?>