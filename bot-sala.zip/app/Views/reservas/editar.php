<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow border-0">
            <div class="card-header bg-warning text-dark fw-bold">Editar Reserva</div>
            <div class="card-body p-4">

                <form action="<?= base_url('reservas/atualizar/' . $reserva['id']) ?>" method="POST">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Sala</label>
                        <select name="sala_id" class="form-select" required>
                            <?php foreach ($salas as $sala): ?>
                                <option value="<?= $sala['id'] ?>" <?= ($sala['id'] == $reserva['sala_id']) ? 'selected' : '' ?>>
                                    <?= $sala['nome'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Data</label>
                        <input type="date" name="data_reserva" class="form-control" value="<?= $reserva['data_reserva'] ?>" required>
                    </div>

                    <div class="row mb-3">
                        <div class="col">
                            <label class="form-label fw-bold">Início</label>
                            <input type="time" name="hora_inicio" class="form-control" value="<?= $reserva['hora_inicio'] ?>" required>
                        </div>
                        <div class="col">
                            <label class="form-label fw-bold">Fim</label>
                            <input type="time" name="hora_fim" class="form-control" value="<?= $reserva['hora_fim'] ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-bold">Descrição/Motivo</label>
                        <textarea name="descricao" class="form-control" rows="3"><?= $reserva['descricao'] ?></textarea>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <a href="javascript:history.back()" class="btn btn-light border">Voltar</a>
                        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>