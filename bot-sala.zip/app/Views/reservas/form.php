<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow border-0">
            <div class="card-header bg-dark text-white p-3">
                <h5 class="mb-0">🤖 Assistente de Agendamento</h5>
            </div>
            <div class="card-body p-4">
                
                <?php if (session()->getFlashdata('error')): ?>
                    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
                <?php endif; ?>

                <form action="<?= base_url('reservas/agendar') ?>" method="POST">
                    <?= csrf_field() ?>

                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label font-weight-bold">Qual sala deseja reservar?</label>
                            <select name="sala_id" class="form-select form-select-lg" required>
                                <option value="">Selecione uma sala...</option>
                                <?php foreach($salas as $sala): ?>
                                    <option value="<?= $sala['id'] ?>">
                                        <?= $sala['nome'] ?> (Capacidade: <?= $sala['capacidade'] ?> pessoas)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Data</label>
                            <input type="date" name="data_reserva" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Início</label>
                            <input type="time" name="hora_inicio" class="form-control" required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Término</label>
                            <input type="time" name="hora_fim" class="form-control" required>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label class="form-label">Título da Reunião / Pauta</label>
                            <input type="text" name="descricao" class="form-control" placeholder="Ex: Alinhamento de Projeto Semanal">
                        </div>
                    </div>

                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-primary btn-lg">Verificar e Confirmar Reserva</button>
                        <a href="<?= base_url('/') ?>" class="btn btn-link text-muted">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>