<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="card shadow border-0">
    <div class="card-body">
        <h3 class="mb-4">Disponibilidade de Salas 📅</h3>
        <div id='calendar'></div>
    </div>
</div>

<link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.css' rel='stylesheet' />
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/main.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.11.3/locales/pt-br.js'></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'pt-br',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: '<?= base_url('reservas/eventos-json') ?>' // Rota que criamos acima
    });
    calendar.render();
});
</script>

<style>
    #calendar { max-height: 700px; }
    .fc-event { cursor: pointer; }
</style>
<?= $this->endSection() ?>