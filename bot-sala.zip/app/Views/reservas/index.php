<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Minhas Reservas 🗓️</h2>
    <a href="<?= base_url('reservas/nova') ?>" class="btn btn-primary">Nova Reserva</a>
</div>
<form action="<?= base_url('reservas') ?>" method="GET" class="row g-3 mb-4">
    <div class="col-auto">
        <label>Filtrar por data:</label>
        <input type="date" name="data" class="form-control" value="<?= $data_selecionada ?>">
    </div>
    <div class="col-auto d-flex align-items-end">
        <button type="submit" class="btn btn-secondary">Filtrar</button>
        <a href="<?= base_url('reservas') ?>" class="btn btn-link">Limpar</a>
    </div>
</form>
<div class="card shadow">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Data</th>
                    <th>Início</th>
                    <th>Fim</th>
                    <th>Sala</th>
                    <th>Descrição</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reservas)): ?>
                    <tr>
                        <td colspan="6" class="text-center">Nenhuma reserva encontrada.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($reservas as $reserva):
                        // Lógica de tempo para o Status
                        $agora = new DateTime();
                        $fimReserva = new DateTime($reserva['data_reserva'] . ' ' . $reserva['hora_fim']);
                        $finalizada = ($agora > $fimReserva);
                    ?>
                        <tr style="<?= $finalizada ? 'opacity: 0.6; background-color: #fdfdfd;' : '' ?>">
                            <td><?= date('d/m/Y', strtotime($reserva['data_reserva'])) ?></td>
                            <td><?= $reserva['hora_inicio'] ?></td>
                            <td><?= $reserva['hora_fim'] ?></td>

                            <td><strong><?= $reserva['nome_sala'] ?></strong></td>

                            <td><?= $reserva['descricao'] ?></td>

                            <td class="text-center">
                                <?php if ($finalizada): ?>
                                    <span class="badge bg-success">Finalizado</span>
                                <?php else: ?>
                                    <div class="btn-group gap-2" role="group">
                                        <a href="<?= base_url('reservas/editar/' . $reserva['id']) ?>"
                                            class="btn btn-sm btn-outline-warning"
                                            title="Editar Reserva">
                                            ✏️
                                        </a>

                                        <a href="<?= base_url('reservas/cancelar/' . $reserva['id']) ?>"
                                            class="btn btn-sm btn-outline-danger"
                                            onclick="return confirm('Tem certeza que deseja cancelar esta reserva?')"
                                            title="Cancelar Reserva">
                                            🗑️
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center mt-3">
            <?= $pager->links() ?>
        </div>
    </div>
</div>
<?= $this->endSection() ?>