<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Cadastrar Nova Sala</h5>
            </div>
            <div class="card-body">
                <form action="<?= base_url('salas/salvar') ?>" method="POST">
                    <?= csrf_field() ?> <div class="mb-3">
                        <label class="form-label">Nome da Sala</label>
                        <input type="text" name="nome" class="form-control" placeholder="Ex: Sala de Reunião A" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Capacidade (Pessoas)</label>
                        <input type="number" name="capacidade" class="form-control" placeholder="Ex: 8" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Recursos Disponíveis</label>
                        <textarea name="recursos" class="form-control" rows="2" placeholder="Ex: TV, Ar-condicionado, Quadro Branco"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success w-100">Salvar Sala</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>