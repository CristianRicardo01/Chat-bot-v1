<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Gerenciar Salas 🏢</h2>
    <a href="<?= base_url('salas/nova') ?>" class="btn btn-primary">Nova Sala</a>
</div>

<div class="card shadow">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Capacidade</th>
                    <th>Recursos</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($salas as $sala): ?>
                <tr>
                    <td><?= $sala['id'] ?></td>
                    <td><?= $sala['nome'] ?></td>
                    <td><?= $sala['capacidade'] ?> pessoas</td>
                    <td><?= $sala['recursos'] ?></td>
                    <td>
                        <span class="badge <?= $sala['status'] == 'disponivel' ? 'bg-success' : 'bg-danger' ?>">
                            <?= $sala['status'] ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>