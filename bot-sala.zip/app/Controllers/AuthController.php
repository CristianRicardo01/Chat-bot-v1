<?php
namespace App\Controllers;
use App\Models\UsuarioModel;

class AuthController extends BaseController {

    public function login() { return view('auth/login'); }
    public function registro() { return view('auth/registro'); }

    public function cadastrar() {
        $model = new UsuarioModel();
        $senha = $this->request->getPost('senha');
        
        $data = [
            'nome'  => $this->request->getPost('nome'),
            'email' => $this->request->getPost('email'),
            'senha' => password_hash($senha, PASSWORD_DEFAULT),
            'nivel' => 1 // Todo novo usuário nasce como nível 1 (Normal)
        ];

        $model->save($data);
        return redirect()->to('/login')->with('success', 'Cadastro realizado! Faça login.');
    }

    public function autenticar() {
        $session = session();
        $model = new UsuarioModel();
        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');

        $usuario = $model->where('email', $email)->first();

        if ($usuario && password_verify($senha, $usuario['senha'])) {
            $session->set([
                'id'       => $usuario['id'],
                'nome'     => $usuario['nome'],
                'nivel'    => $usuario['nivel'],
                'isLogger' => true
            ]);
            return redirect()->to('/dashboard');
        }

        return redirect()->back()->with('error', 'E-mail ou senha inválidos.');
    }

    public function logout() {
        session()->destroy();
        return redirect()->to('/');
    }
}