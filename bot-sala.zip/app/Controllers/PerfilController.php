<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class PerfilController extends BaseController
{
    public function index()
    {
        $usuarioModel = new UsuarioModel();
        // Busca os dados do utilizador logado na sessão
        $data['usuario'] = $usuarioModel->find(session()->get('id'));

        return view('perfil/index', $data);
    }

    public function salvar()
    {
        $usuarioModel = new UsuarioModel();
        $id = session()->get('id');

        $dados = [
            'nome' => $this->request->getPost('nome'),
        ];

        // Só altera a senha se o utilizador digitou algo no campo
        $novaSenha = $this->request->getPost('senha');
        if (!empty($novaSenha)) {
            $dados['senha'] = password_hash($novaSenha, PASSWORD_DEFAULT);
        }

        if ($usuarioModel->update($id, $dados)) {
            // Atualiza o nome na sessão também para mudar no topo do site na hora
            session()->set('nome', $dados['nome']);

            return redirect()->to('/perfil')->with('success', 'Perfil atualizado com sucesso!');
        }

        return redirect()->back()->with('error', 'Erro ao atualizar perfil.');
    }
}
