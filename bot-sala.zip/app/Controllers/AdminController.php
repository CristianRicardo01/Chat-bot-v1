<?php

namespace App\Controllers;

use App\Models\ReservaModel;
use App\Models\UsuarioModel;

class AdminController extends BaseController
{
    // 2. Paginação para Gerenciar Usuários
    public function usuarios()
    {
        $usuarioModel = new UsuarioModel();

        $data = [
            'usuarios' => $usuarioModel->paginate(10, 'usuarios'),
            'pager'    => $usuarioModel->pager
        ];

        return view('admin/usuarios', $data);
    }

    public function mudarNivel($id, $novoNivel)
    {
        $model = new UsuarioModel();

        // Evita que o admin logado mude o próprio nível (segurança)
        if ($id == session()->get('id')) {
            return redirect()->back()->with('error', 'Você não pode alterar seu próprio nível de acesso.');
        }

        $model->update($id, ['nivel' => $novoNivel]);

        return redirect()->back()->with('success', 'Nível de acesso atualizado com sucesso!');
    }

    // 1. Paginação para Gestão Global de Reservas
    public function todasReservas()
    {
        $reservaModel = new ReservaModel();
        $dataFiltro = $this->request->getGet('data');

        // Configura o Model com os JOINS
        $reservaModel->select('reservas.*, salas.nome as nome_sala, usuarios.nome as nome_usuario')
            ->join('salas', 'salas.id = reservas.sala_id')
            ->join('usuarios', 'usuarios.id = reservas.usuario_id');

        if ($dataFiltro) {
            $reservaModel->where('reservas.data_reserva', $dataFiltro);
        }

        $data = [
            'reservas' => $reservaModel->paginate(10, 'reservas'), // 10 por página
            'pager'    => $reservaModel->pager,
            'data_selecionada' => $dataFiltro
        ];

        return view('admin/todas_reservas', $data);
    }
    // No AdminController.php
    public function alterarSenhaUsuario($id)
    {
        $model = new UsuarioModel();
        $novaSenha = $this->request->getPost('nova_senha');

        $model->update($id, [
            'senha' => password_hash($novaSenha, PASSWORD_DEFAULT)
        ]);

        return redirect()->back()->with('success', 'Senha atualizada com sucesso!');
    }
}
