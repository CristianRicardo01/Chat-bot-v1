<?php

namespace App\Controllers;

use App\Models\ReservaModel;
use App\Models\SalaModel;
use CodeIgniter\RESTful\ResourceController;

class ChatbotController extends ResourceController
{
    protected $format = 'json';

    public function processar()
    {
        $session = session();
        $usuarioId = $session->get('id');
        $mensagemOriginal = $this->request->getPost('mensagem');

        if (!$mensagemOriginal) {
            return $this->respond(['resposta' => 'Opa, não recebi a sua mensagem.']);
        }

        $mensagem = trim($mensagemOriginal);
        $msgLower = mb_strtolower($mensagem);

        // 1. Verificar se existe um fluxo de reserva ativo na sessão
        $flow = $session->get('reserva_flow');

        // Se o usuário digitar sair ou cancelar, interrompemos qualquer fluxo
        if ($msgLower === 'sair' || $msgLower === 'cancelar') {
            $session->remove('reserva_flow');
            return $this->respond(['resposta' => "Processo cancelado. Como posso ajudar agora?"]);
        }

        // Se houver um fluxo ativo, a mensagem atual é uma resposta a uma pergunta do bot
        if ($flow) {
            return $this->continuarReserva($mensagem, $flow);
        }

        // 2. Comandos Principais (Iniciados com !)

        // COMANDO: !Informações
        if ($msgLower === "!informações" || $msgLower === "!informacoes" || $msgLower === "!ajuda") {
            return $this->respond([
                'resposta' => "📋 *Menu de Comandos*:\n\n" .
                    "🔹 `!Salas` - Ver salas livres agora\n" .
                    "🔹 `!Reservas` - Ver meus agendamentos\n" .
                    "🔹 `!Reservar` - Iniciar novo agendamento\n" .
                    "🔹 `!Informações` - Mostrar este menu"
            ]);
        }

        // COMANDO: !Salas
        if ($msgLower === "!salas") {
            return $this->listarSalasLivres();
        }

        // COMANDO: !Reservas
        if ($msgLower === "!reservas") {
            return $this->minhasReservas($usuarioId);
        }

        // COMANDO: !Reservar (Inicia o fluxo)
        if ($msgLower === "!reservar") {
            $salaModel = new SalaModel();
            $salas = $salaModel->findAll();

            $listaSalas = "";
            foreach ($salas as $s) {
                $listaSalas .= "• " . $s['nome'] . "\n";
            }

            $session->set('reserva_flow', ['step' => 'aguardando_sala']);

            return $this->respond([
                'resposta' => "🚀 **Iniciando Reserva**\n\nPor favor, digite o **nome da sala** exatamente como listado abaixo:\n\n" . $listaSalas . "\n(Ou digite 'cancelar')"
            ]);
        }

        // 3. Validação de segurança: Esqueceu o "!"?
        $comandosSemPrefixo = ['salas', 'reservas', 'informações', 'informacoes', 'ajuda', 'reservar'];
        if (in_array($msgLower, $comandosSemPrefixo)) {
            return $this->respond([
                'resposta' => "Ops! Para eu entender, use o `!` antes do comando. \nExemplo: `!$mensagem` 😉"
            ]);
        }

        // 4. Resposta padrão
        return $this->respond([
            'resposta' => "Comando não reconhecido. 🤔\nDigite `!Informações` para ver o que eu posso fazer."
        ]);
    }

    private function continuarReserva($mensagem, $flow)
    {
        $session = session();
        $step = $flow['step'];

        switch ($step) {
            case 'aguardando_sala':
                $salaModel = new \App\Models\SalaModel();
                $sala = $salaModel->where('nome', $mensagem)->first();

                if (!$sala) {
                    return $this->respond(['resposta' => "⚠️ Não encontrei a sala '$mensagem'. Digite o nome exatamente como aparece na lista:"]);
                }

                $flow['sala_id'] = $sala['id'];
                $flow['sala_nome'] = $sala['nome'];
                $flow['step'] = 'aguardando_data';
                $session->set('reserva_flow', $flow);
                return $this->respond(['resposta' => "Sala **{$sala['nome']}** selecionada!\nQual a **data**? (Ex: 23/12/2025)"]);

            case 'aguardando_data':
                $dataLimpa = str_replace('/', '-', $mensagem);
                $dataFormatada = date('Y-m-d', strtotime($dataLimpa));

                if ($dataFormatada < date('Y-m-d')) {
                    return $this->respond(['resposta' => "❌ Você não pode reservar uma data retroativa. Digite uma data futura:"]);
                }

                $flow['data'] = $dataFormatada;
                $flow['step'] = 'aguardando_horario';
                $session->set('reserva_flow', $flow);
                return $this->respond(['resposta' => "Anotado: $mensagem.\nAgora o **horário**? (Use o padrão: 14:00 às 15:00)"]);

            case 'aguardando_horario':
                preg_match_all('/(\d{2}:\d{2})/', $mensagem, $matches);

                if (count($matches[0]) < 2) {
                    return $this->respond(['resposta' => "⚠️ Não entendi o horário. Use o formato: **00:00 às 00:00**"]);
                }

                $horaInicio = $matches[0][0];
                $horaFim    = $matches[0][1];

                $reservaModel = new \App\Models\ReservaModel();
                $conflito = $reservaModel->where('sala_id', $flow['sala_id'])
                    ->where('data_reserva', $flow['data'])
                    ->groupStart()
                    ->where("('$horaInicio' >= hora_inicio AND '$horaInicio' < hora_fim)")
                    ->orWhere("('$horaFim' > hora_inicio AND '$horaFim' <= hora_fim)")
                    ->orWhere("(hora_inicio >= '$horaInicio' AND hora_inicio < '$horaFim')")
                    ->groupEnd()
                    ->first();

                if ($conflito) {
                    $session->remove('reserva_flow');
                    return $this->respond([
                        'resposta' => "❌ **Erro no Agendamento:**\nA sala **{$flow['sala_nome']}** já está ocupada neste horário.\n\nDigite `!Reservar` para tentar outro horário."
                    ]);
                }

                try {
                    $reservaModel->save([
                        'sala_id'      => $flow['sala_id'],
                        'usuario_id'   => $session->get('id'),
                        'data_reserva' => $flow['data'],
                        'hora_inicio'  => $horaInicio,
                        'hora_fim'     => $horaFim,
                        'status'       => 'Confirmado'
                    ]);

                    $session->remove('reserva_flow');

                    // AQUI ESTÁ A CORREÇÃO: Adicionado o 'status' => 'success'
                    return $this->respond([
                        'status'   => 'success',
                        'resposta' => "✅ **RESERVA CONCLUÍDA COM SUCESSO!**\n\n🏢 Sala: {$flow['sala_nome']}\n🗓️ Data: " . date('d/m/Y', strtotime($flow['data'])) . "\n⏰ Horário: $horaInicio às $horaFim\n\nSeu compromisso já está no calendário! 🚀"
                    ]);
                } catch (\Exception $e) {
                    return $this->respond(['resposta' => "🔥 Erro interno ao salvar: " . $e->getMessage()]);
                }
        }
    }

    private function listarSalasLivres()
    {
        $salaModel = new SalaModel();
        $reservaModel = new ReservaModel();

        $hoje = date('Y-m-d');
        $horaAtual = date('H:i:s');

        $salasOcupadas = $reservaModel->where('data_reserva', $hoje)
            ->groupStart()
            ->where("hora_inicio <= '$horaAtual'")
            ->where("hora_fim >= '$horaAtual'")
            ->groupEnd()
            ->findColumn('sala_id') ?: [0];

        $salasLivres = $salaModel->whereNotIn('id', $salasOcupadas)->findAll();

        if (empty($salasLivres)) {
            return $this->respond(['resposta' => "Infelizmente todas as salas estão ocupadas agora. 🏢"]);
        }

        $lista = "🏢 *Salas Livres Agora:*\n\n";
        foreach ($salasLivres as $s) {
            $lista .= "✅ " . $s['nome'] . " (Cap.: " . $s['capacidade'] . ")\n";
        }

        $lista .= "\n━━━━━━━━━━━━━━━\n👉 Para reservar, use: `!Reservar`";
        return $this->respond(['resposta' => $lista]);
    }

    private function minhasReservas($userId)
    {
        $reservaModel = new ReservaModel();
        $reservas = $reservaModel->select('reservas.*, salas.nome as nome_sala')
            ->join('salas', 'salas.id = reservas.sala_id')
            ->where('usuario_id', $userId)
            ->where('data_reserva >=', date('Y-m-d'))
            ->orderBy('data_reserva', 'ASC')
            ->limit(5)
            ->find();

        if (empty($reservas)) {
            return $this->respond(['resposta' => "Você não possui reservas futuras. 🗓️"]);
        }

        $resp = "🗓️ *Suas Próximas Reservas:*\n\n";
        foreach ($reservas as $r) {
            $data = date('d/m', strtotime($r['data_reserva']));
            $resp .= "🔹 $data às " . substr($r['hora_inicio'], 0, 5) . " - " . $r['nome_sala'] . "\n";
        }

        return $this->respond(['resposta' => $resp]);
    }
}
