<?php

namespace App\Controllers;

use App\Models\SalaModel;
use CodeIgniter\Controller;

class SalaController extends BaseController
{
    public function index()
    {
        $salaModel = new SalaModel();

        // Busca todas as salas cadastradas
        $data['salas'] = $salaModel->findAll();

        return view('salas/index', $data);
    }
    
    // 1. Exibe o formulário de cadastro
    public function criar()
    {
        return view('salas/form');
    }

    // 2. Recebe os dados do formulário e salva no Banco de Dados
    public function salvar()
    {
        $salaModel = new SalaModel();

        // Pega os dados do POST
        $data = [
            'nome'       => $this->request->getPost('nome'),
            'capacidade' => $this->request->getPost('capacidade'),
            'recursos'   => $this->request->getPost('recursos'),
            'status'     => 'disponivel'
        ];

        // Tenta salvar no banco
        if ($salaModel->save($data)) {
            // Se der certo, volta para a lista de salas (ou para o formulário) com mensagem de sucesso
            return redirect()->to('/salas/nova')->with('success', 'Sala cadastrada com sucesso!');
        } else {
            // Se der erro, volta com os erros
            return redirect()->back()->withInput()->with('errors', $salaModel->errors());
        }
    }
}
