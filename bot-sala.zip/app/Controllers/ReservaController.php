<?php

namespace App\Controllers;

use App\Models\ReservaModel;
use App\Models\SalaModel;

class ReservaController extends BaseController
{
    public function index()
    {
        $reservaModel = new ReservaModel();
        $dataFiltro = $this->request->getGet('data');
        $usuarioLogadoId = session()->get('id');

        // Define quem o usuário pode ver
        if (session()->get('nivel') == 0) {
            // Admin vê todos
            if ($dataFiltro) {
                $reservaModel->where('reservas.data_reserva', $dataFiltro);
            }
        } else {
            // Usuário comum vê só as dele
            $reservaModel->where('reservas.usuario_id', $usuarioLogadoId);
            if ($dataFiltro) {
                $reservaModel->where('reservas.data_reserva', $dataFiltro);
            }
        }

        // JOINS necessários para o nome da sala e usuário
        $reservaModel->select('reservas.*, salas.nome as nome_sala, usuarios.nome as nome_usuario')
            ->join('salas', 'salas.id = reservas.sala_id')
            ->join('usuarios', 'usuarios.id = reservas.usuario_id');

        $data = [
            // O número '10' define quantos itens aparecem por página
            'reservas' => $reservaModel->paginate(10),
            'pager'    => $reservaModel->pager,
            'data_selecionada' => $dataFiltro
        ];

        return view('reservas/index', $data);
    }

    public function criar()
    {
        $salaModel = new SalaModel();
        $data['salas'] = $salaModel->where('status', 'disponivel')->findAll();
        return view('reservas/form', $data);
    }
    // 1. Exibir o formulário de edição
    public function editar($id)
    {
        $reservaModel = new ReservaModel();
        $salaModel = new SalaModel();

        $reserva = $reservaModel->find($id);

        // Segurança: Só o dono ou Admin acessa
        if (!$reserva || ($reserva['usuario_id'] != session()->get('id') && session()->get('nivel') != 0)) {
            return redirect()->to('/dashboard')->with('error', 'Acesso negado.');
        }

        $data = [
            'reserva' => $reserva,
            'salas'   => $salaModel->where('status', 'disponivel')->findAll()
        ];

        return view('reservas/editar', $data);
    }

    // 2. Processar a atualização
    public function atualizar($id)
    {
        $reservaModel = new ReservaModel();

        // Dados para atualizar
        $dados = [
            'sala_id'      => $this->request->getPost('sala_id'),
            'data_reserva' => $this->request->getPost('data_reserva'),
            'hora_inicio'  => $this->request->getPost('hora_inicio'),
            'hora_fim'     => $this->request->getPost('hora_fim'),
            'descricao'    => $this->request->getPost('descricao')
        ];

        // Validação de conflito (Opcional: ignorar a própria reserva atual no conflito)
        // Para simplificar agora, vamos apenas salvar:
        $reservaModel->update($id, $dados);

        $rotaDestino = (session()->get('nivel') == 0) ? '/admin/reservas' : '/reservas';
        return redirect()->to($rotaDestino)->with('success', 'Reserva atualizada!');
    }

    public function agendar()
    {
        $reservaModel = new ReservaModel();

        $sala_id = $this->request->getPost('sala_id');
        $data    = $this->request->getPost('data_reserva');
        $inicio  = $this->request->getPost('hora_inicio');
        $fim     = $this->request->getPost('hora_fim');

        // 1. Verifica disponibilidade
        $conflito = $reservaModel->verificarDisponibilidade($sala_id, $data, $inicio, $fim);

        if ($conflito) {
            return redirect()->back()->with('error', 'Ops! Essa sala já está reservada neste horário.');
        }

        // 2. Salva usando o ID REAL da sessão
        $reservaModel->save([
            'usuario_id'   => session()->get('id'),
            'sala_id'      => $sala_id,
            'data_reserva' => $data,
            'hora_inicio'  => $inicio,
            'hora_fim'     => $fim,
            'descricao'    => $this->request->getPost('descricao')
        ]);

        return redirect()->to('/dashboard')->with('success', 'Reserva confirmada com sucesso!');
    }

    public function cancelar($id)
    {
        $reservaModel = new ReservaModel();
        $reserva = $reservaModel->find($id);

        if (!$reserva) {
            return redirect()->back()->with('error', 'Reserva não encontrada.');
        }

        // Segurança: Dono da reserva ou Admin
        if ($reserva['usuario_id'] == session()->get('id') || session()->get('nivel') == 0) {
            $reservaModel->delete($id);
            return redirect()->back()->with('success', 'Reserva cancelada com sucesso!');
        }

        return redirect()->back()->with('error', 'Você não tem permissão para isso.');
    }

    public function eventosJson()
    {
        $reservaModel = new ReservaModel();
        // Buscamos todas as reservas com os nomes das salas
        $reservas = $reservaModel->select('reservas.*, salas.nome as nome_sala')
            ->join('salas', 'salas.id = reservas.sala_id')
            ->findAll();

        $eventos = [];
        foreach ($reservas as $r) {
            $eventos[] = [
                'title' => $r['nome_sala'] . ' - ' . $r['descricao'],
                'start' => $r['data_reserva'] . 'T' . $r['hora_inicio'],
                'end'   => $r['data_reserva'] . 'T' . $r['hora_fim'],
                'color' => '#3788d8' // Você pode personalizar a cor por sala depois
            ];
        }

        return $this->response->setJSON($eventos);
    }

    // Método para carregar a página do calendário grande
    public function calendario()
    {
        return view('reservas/calendario_completo');
    }
}
