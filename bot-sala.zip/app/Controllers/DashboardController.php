<?php

namespace App\Controllers;

use App\Models\ReservaModel;
use App\Models\SalaModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $reservaModel = new ReservaModel();
        $salaModel    = new SalaModel();
        $userId       = session()->get('id');

        $dataFiltro = $this->request->getGet('data_busca');
        $hoje       = date('Y-m-d');

        // IMPORTANTE: O select deve conter 'salas.nome as nome_sala'
        $reservaModel->select('reservas.*, salas.nome as nome_sala')
            ->join('salas', 'salas.id = reservas.sala_id')
            ->where('usuario_id', $userId);

        if ($dataFiltro) {
            $reservaModel->where('data_reserva', $dataFiltro);
        } else {
            $reservaModel->where('data_reserva >=', $hoje);
        }

        $data = [
            'minhasReservas'   => $reservaModel->where('usuario_id', $userId)->countAllResults(false), // false para não resetar o query builder
            'reservasHoje'     => (new ReservaModel())->where('data_reserva', $hoje)->countAllResults(),
            'totalSalas'       => $salaModel->countAll(),
            'data_selecionada' => $dataFiltro,
            // Paginação
            'proximasReservas' => $reservaModel->orderBy('data_reserva', 'ASC')->paginate(5, 'dashboard'),
            'pager'            => $reservaModel->pager
        ];

        return view('dashboard/index', $data);
    }
}
