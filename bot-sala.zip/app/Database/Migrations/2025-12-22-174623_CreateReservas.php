<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateReservas extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'usuario_id' => [
                'type'       => 'INT',
                'unsigned'   => true,
            ],
            'sala_id' => [
                'type'       => 'INT',
                'unsigned'   => true,
            ],
            'data_reserva' => [
                'type' => 'DATE',
            ],
            'hora_inicio' => [
                'type' => 'TIME',
            ],
            'hora_fim' => [
                'type' => 'TIME',
            ],
            'descricao' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
                'null'       => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        
        // Chaves Estrangeiras para manter a integridade
        $this->forge->addForeignKey('usuario_id', 'usuarios', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('sala_id', 'salas', 'id', 'CASCADE', 'CASCADE');
        
        $this->forge->createTable('reservas');
    }

    public function down()
    {
        $this->forge->dropTable('reservas');
    }
}