<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddAuthFieldsToUsuarios extends Migration
{
    public function up()
    {
        $fields = [
            'nivel' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1, // 0 = Admin, 1 = Usuário Comum
                'after'      => 'senha',
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ];
        $this->forge->addColumn('usuarios', $fields);
    }

    public function down()
    {
        $this->forge->dropColumn('usuarios', ['senha', 'nivel', 'updated_at']);
    }
}