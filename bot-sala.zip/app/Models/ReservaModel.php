<?php

namespace App\Models;

use CodeIgniter\Model;

class ReservaModel extends Model
{
    protected $table            = 'reservas';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['usuario_id', 'sala_id', 'data_reserva', 'hora_inicio', 'hora_fim', 'descricao'];
    protected $useTimestamps = false;
    /**
     * Função que o Bot usará para verificar se a sala está livre
     */
    public function verificarDisponibilidade($sala_id, $data, $inicio, $fim)
    {
        return $this->where('sala_id', $sala_id)
            ->where('data_reserva', $data)
            ->groupStart()
            ->where("hora_inicio <", $fim)
            ->where("hora_fim >", $inicio)
            ->groupEnd()
            ->first();
    }
    // Nova função para buscar reservas com nomes das salas
    public function getReservasComSalas($usuario_id = null, $data = null)
    {
        $builder = $this->db->table($this->table);

        // Selecionamos os campos da reserva, o nome da sala e o nome do usuário
        $builder->select('reservas.*, salas.nome as nome_sala, usuarios.nome as nome_usuario');

        // Unimos com as tabelas de salas e usuários
        $builder->join('salas', 'salas.id = reservas.sala_id');
        $builder->join('usuarios', 'usuarios.id = reservas.usuario_id');

        // Filtros opcionais
        if ($usuario_id) {
            $builder->where('reservas.usuario_id', $usuario_id);
        }

        if ($data) {
            $builder->where('reservas.data_reserva', $data);
        }

        return $builder->get()->getResultArray();
    }
}
